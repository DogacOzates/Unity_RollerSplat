﻿namespace GG.Infrastructure.Utils.Swipe
{
    public class Errors
    {
        public const string SWIPE_PARAMETERS_NULL = "swipeParameters can not be null!";
        public const string SWIPE_PARAMETERS_EMPTY = "swipeParameters can not be empty!";
        public const string CANT_FIND_SWIPE = "Can not find swipe!";
    }
}
